=== RV Embed PDF ===
Contributors: premek.v
Tags: pdf, embed, Add Media, Google Docs Viewer, upload
Requires at least: 3.5
Tested up to: 3.5
Stable tag: trunk

Embeds a PDF in your page or post when you insert it with the Add Media button.

== Description ==

When you upload PDF and insert a link to it with the Add Media button, it will be automatically embedded in the page using Google Docs Viewer.

Use the Add other media button above the editor to insert a pdf file and embed
will be inserted automatically.

Brought to you by [Rong Vang Media](http://www.rongvang.cz).

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload to the `/wp-content/plugins/` (Or use the Install plugins menu option in your WP.)
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Nothing. Done.

== Frequently Asked Questions ==

none..

== Screenshots ==

1. Embedded PDF


== Changelog ==

= 1.1 =
* Changed to be compatible with wp 3.5. Not tested with older wp versions.

= 1.0 =
* First version. No changes.

