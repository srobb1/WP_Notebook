{
	"sProcessing":	   "Traitement en cours...",
	"sLengthMenu":	   "Afficher _MENU_ &eacute;l&eacute;ments",
	"sZeroRecords":	   "Aucun &eacute;l&eacute;ment &agrave; afficher",
	"sInfo":		   "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
	"sInfoEmpty":	   "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
	"sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
	"sInfoPostFix":	   "",
	"sSearch":		   "Rechercher&nbsp;:",
	"sLoadingRecords": "Téléchargement...",
	"oPaginate": {
		"sFirst":	 "Premier",
		"sPrevious": "Pr&eacute;c&eacute;dent",
		"sNext":	 "Suivant",
		"sLast":	 "Dernier"
	}
}