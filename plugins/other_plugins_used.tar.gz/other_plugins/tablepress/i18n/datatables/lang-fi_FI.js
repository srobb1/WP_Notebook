{
	"sProcessing":	 "Hetkinen...",
	"sLengthMenu":	 "Näytä kerralla _MENU_ riviä",
	"sZeroRecords":	 "Tietoja ei löytynyt",
	"sInfo":		 "Näytetään rivit _START_ - _END_ (yhteensä _TOTAL_ )",
	"sInfoEmpty":	 "Näytetään 0 - 0 (yhteensä 0)",
	"sInfoFiltered": "(suodatettu _MAX_ tuloksen joukosta)",
	"sInfoPostFix":	 "",
	"sSearch":		 "Etsi:",
	"oPaginate": {
		"sFirst":	 "Ensimmäinen",
		"sPrevious": "Edellinen",
		"sNext":	 "Seuraava",
		"sLast":	 "Viimeinen"
	}
}