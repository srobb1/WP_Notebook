<!-- begin footer -->
</div>

<?php get_sidebar(); ?>



<div id="footer">
<?php wp_footer(); ?>
<p class="credit">Powered by <a href="http://wordspress.org">WordPress</a><br/>
Theme from <a href="http://grabatheme.com" title="exclusive themes for WordPress">Grab A Theme</a>, <a 
href="http://www.sharphosts.com" title="Web Hosting Reviews">Web Hosting Reviews </a>, <a href="http://www.hostseeq.com/c/internet_marketing.htm" title="Perfumes">Internet Marketing</a> & <a href="http://www.myperfumeshoes.com" title="Perfumes">Perfumes</a>
</p>

</div>
</div>
</body>
</html>