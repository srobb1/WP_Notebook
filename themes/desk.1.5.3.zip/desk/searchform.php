<form method="get" class="searchform" action="<?php echo home_url(); ?>" >
	<div>
	<input type="text" value="" name="s" class="s" />
	<input type="submit" class="searchsubmit" value="Search" />
	</div>
	</form>
