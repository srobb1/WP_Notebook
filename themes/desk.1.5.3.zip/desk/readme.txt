Desk Theme by Nearfrog Designs

http://nearfrog.com

I hope you enjoy this theme. Please visit my site or the wordpress.org forums for any help or suggestions.


Changes

1.5.3
- Very minor styling fix (media embeds sizing issue)

1.5.2
- None, 1.5.0/1 upload failed

1.5.0
- Completely remade options system using the WP Settings API. Theme menu is now under "appearance". WARNING: This will reset all previously set options, including additional code you may have entered into the last options page.
- Option to hide featured image on single post view
- Option to replace heading & description with custom image
- Minor styling tweaks

1.0.4
- Minor styling changes including category heirachy for widget
- Doctype change: increased simplicity for html5 compatibility
- Custon feed URL for the menu rss icon

1.0.3
- Added options page in backend for a variety of options