<?php 
/* @package WordPress
 * @subpackage Desk
 */
?>
<?php
get_header();
?>
<div id="post">
	
	<div class="entry">
		<div class="posthead">
			<h2>Sorry, Page not found - 404 Error
			</h2>
			
		</div>

			<p>It seems the page you are looking for has moved or does not exist. Please use the menu above or return to the <a href="<?php echo home_url(); ?>">home page</a></p>
			
	</div>
	

	
	
	
	</div>
<?php get_sidebar(); ?><?php get_footer(); ?>